-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 21/09/2023 às 23:34
-- Versão do servidor: 10.4.22-MariaDB
-- Versão do PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `MeetTalk`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `matchsUsuario`
--

CREATE TABLE `matchsUsuario` (
  `email_usuario` varchar(255) NOT NULL,
  `email_match` varchar(255) NOT NULL,
  `data_match` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `matchsUsuario`
--

INSERT INTO `matchsUsuario` (`email_usuario`, `email_match`, `data_match`) VALUES
('america@gmail.com', 'renan@gmail.com', '2023-09-21 04:10:39'),
('renan@gmail.com', 'leticia@gmail.com', '2023-09-19 20:47:16'),
('testando@gmail.com', 'jus@gmail.com', '2023-09-20 17:42:07'),
('teste1@gmail.com', 'teste2@gmail.com', '2023-09-20 22:14:03'),
('teste1@gmail.com', 'teste4@gmail.com', '2023-09-19 22:07:47'),
('teste4@gmail.com', 'teste1@gmail.com', '2023-09-21 09:32:02');

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagemDia`
--

CREATE TABLE `mensagemDia` (
  `usuario_email` varchar(255) NOT NULL,
  `texto` varchar(255) DEFAULT NULL,
  `horario` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `mensagemDia`
--

INSERT INTO `mensagemDia` (`usuario_email`, `texto`, `horario`) VALUES
('renan@gmail.com', 'popopo', '2023-09-20 20:47:32'),
('teste1@gmail.com', 'Oi', '2023-09-21 09:59:33'),
('teste4@gmail.com', 'testanto msg', '2023-09-21 09:40:44');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `genero` varchar(255) NOT NULL,
  `data_nascimento` date NOT NULL,
  `esporte` varchar(255) NOT NULL,
  `estilo_musical` varchar(255) NOT NULL,
  `maior_qualidade` varchar(255) NOT NULL,
  `maior_defeito` varchar(255) NOT NULL,
  `genero_literario` varchar(255) NOT NULL,
  `genero_filme` varchar(255) NOT NULL,
  `status_relacionamento` varchar(255) NOT NULL,
  `religiao` varchar(255) NOT NULL,
  `sexualidade` varchar(255) NOT NULL,
  `pais` varchar(255) NOT NULL,
  `fotoPerfil` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`email`, `senha`, `nome`, `genero`, `data_nascimento`, `esporte`, `estilo_musical`, `maior_qualidade`, `maior_defeito`, `genero_literario`, `genero_filme`, `status_relacionamento`, `religiao`, `sexualidade`, `pais`, `fotoPerfil`) VALUES
('america@gmail.com', '$2y$10$1tetpDTFfVXF3f/NGgB65OWs.KxI0OFG4lhIxxBdZ9dAX3DcuCUge', 'america', 'Feminino', '1111-11-11', 'Natação', 'Reggae', 'aventureiro', 'casmurro', 'Viagem', 'Fantasia científica', 'Casado', 'Judaísmo', 'Assexual', 'Antígua e Barbuda', NULL),
('brenda@gmail.com', '$2y$10$GW1LNhFNDi.gF4PF9enE7uiSMbZNqjC7.HAF5nwdRMb7DgwHEGghO', 'a', 'Feminino', '2000-10-10', 'Atletismo', 'Reggae', 'aventureiro', 'chato', 'Crimes Reais', 'Fantasia', 'Casado', 'Islamismo', 'Prefiro Não Dizer', 'Aruba', NULL),
('carolinagguereiro00@gmail.com', 'carol222', 'caca', 'Feminino', '2006-06-26', 'Corridas', 'Rock', 'bacana', 'bruto', 'Romance', 'Romance', 'Casado', 'Cristianismo', 'Heterossexual', 'Brasil', NULL),
('Charles@gmail.com', 'leclerc', 'charlesLeclerc', 'Masculino', '1997-10-16', 'Corridas', 'Rap', 'alegre', 'chato', 'Horror', 'Drama', 'Divorciado', 'Budismo', 'Heterossexual', 'Mônaco', NULL),
('cone00@gmail.com', 'luca123', 'cone', 'Masculino', '2005-12-12', 'Futebol', 'Pop', 'carinhoso', 'chato', 'Romance', 'Romance', 'Casado', 'Cristianismo', 'Heterossexual', 'Brasil', NULL),
('jj@gmail.com', '$2y$10$F0.2wSZwEibPT4WCZFhir.TzPj1HrlDOO9lARUux7E3nXa/h12VOi', 's', 'Gênero', '2023-08-11', 'Escolha um esporte', 'Genero Musical Favorito', 'Maior qualidade', 'Maior defeito', 'Gênero Literário Favorito', 'Gênero de Filme Favorito', 'Status de Relacionamento', 'Agnóstico', 'Sexualidade', 'País', NULL),
('jordana@gmail.com', '$2y$10$tjd.1wTNqj5fM9H0.z0wi.sJbkQwHBJ3noEjU2SwtHu72QZoANG3K', 'a', 'Feminino', '2023-08-11', 'Tênis', 'Rap', 'aventureiro', 'cínico', 'História', 'Ficção científica', 'Separado', 'Candomblé', 'Heterossexual', 'País', NULL),
('jose@gmail.com', '$2y$10$vnAAeSLSqOAQ2bjaBRbbZeMtAr6.fpagM.3w10p9EeLZ3wwMKwgM6', 'jose', 'Masculino', '2018-01-10', 'Rugby', 'Samba', 'benévolo', 'colérico', 'Arte e Fotografia', 'Faroeste', 'Casado', 'Islamismo', 'Heterossexual', 'Brasil', NULL),
('jus@gmail.com', '$2y$10$71F0PWo..f768CT3I4nU7OIdCIYk1Z5GN1LdkFkbS4xoAj5vaVxgm', 'jus', 'Masculino', '2000-11-11', 'Natação', 'Sertanejo', 'benévolo', 'casmurro', 'História', 'Ficção científica', 'Casado', 'Outro', 'Prefiro Não Dizer', 'Arábia Saudita', NULL),
('leonardo@gmail.com', '$2y$10$GpQX4bmxKagkxO8NBwrTqehC8fhexmL5aA1BIdHZLKSgOVKByu1Vq', 'leo', 'Feminino', '2003-12-12', 'Atletismo', 'Rock', 'bacana', 'chato', 'História', 'Faroeste', 'Namorando', 'Agnóstico', 'Assexual', 'Armênia', NULL),
('leticia@gmail.com', '$2y$10$bUrwqih0.QWiZv2qXxez6.ppg27YNxuXmGhbqQfe9UrMFllF02IMO', 'let', 'Gênero', '1999-09-17', 'Escolha um esporte', 'Genero Musical Favorito', 'Maior qualidade', 'Maior defeito', 'Gênero Literário Favorito', 'Gênero de Filme Favorito', 'Status de Relacionamento', 'Agnóstico', 'Sexualidade', 'País', NULL),
('Lewis@gmail.com', 'Lewis11', 'Hamilton', 'Masculino', '1985-01-07', 'Corridas', 'Rap', 'amoroso', 'birrento', 'Fantasia', 'Fantasia', 'Namorando', 'Ateu', 'Heterossexual', 'Reino Unido', NULL),
('lorengoni@gmail.com', '$2y$10$4l/iaPH2CtMU2Cughr/8cOs6/39kmwljs08otmZrD3j3B2guk88qG', 'goninho', 'Masculino', '2006-07-21', 'Futebol', 'Pop', 'Legal', 'Chato', 'Romance', 'Romance', 'Solteiro', 'Ateu', 'Heterossexual', 'Brasil', NULL),
('renan@gmail.com', '$2y$10$dsnYeKbgllDRzNA/fxXskOPxAGE8a8C6BsiQ0BVaAJF64VH6j.TVS', 'renan', 'Masculino', '2001-12-12', 'Golfe', 'Samba', 'aventureiro', 'calculista', 'Gastronomia', 'Fantasia científica', 'Namorando', 'Islamismo', 'Assexual', 'Turquemenistão', 'uploads/renan@gmail.com.png'),
('rerere@gmail.com', '$2y$10$3UEvyPMwGFrR0H3vldllWeoZEUPJuh9x8GJFJzvfB90Ctoma1.Dh.', 'rere', 'Masculino', '1111-11-11', 'Tênis', 'Rap', 'atencioso', 'calculista', 'Viagem', 'Fantasia científica', 'Namorando', 'Judaísmo', 'Bissexual', 'Áustria', NULL),
('testando@gmail.com', '$2y$10$J3MyAjvFEWr7L7Fo.ROrzOpzygMD4fUofF3i6.AWHKa/MldkxMqdq', 'testando', 'Feminino', '1111-11-11', 'Natação', 'Sertanejo', 'bacana', 'chato', 'Crimes Reais', 'Fantasia científica', 'Namorando', 'Outro', 'Prefiro Não Dizer', 'Austrália', NULL),
('teste1@gmail.com', '$2y$10$UMX5gNeBkZ0qBftsWRSK5.nVdLRLQ2usH76FpyJEv5d998.barl.a', 'teste1', 'Feminino', '1111-11-11', 'Futebol', 'Axé', 'adorável', 'agressivo', 'Fantasia', 'Ação', 'Solteiro', 'Agnóstico', 'Heterossexual', 'Brasil', NULL),
('teste2@gmail.com', '$2y$10$RUUuUBa0xwoj8aVEt6xE3O2cKwue.JGY8129QzOwaepayTS2UG6pW', 'teste2', 'Feminino', '1111-11-11', 'Futebol', 'Axé', 'adorável', 'agressivo', 'Fantasia', 'Ação', 'Solteiro', 'Agnóstico', 'Heterossexual', 'Brasil', NULL),
('teste3@gmail.com', '$2y$10$mkti5o.UdEK5jzZt0v1TE.wgnmHtfl64CwycniF/S.BIvuiMna5Zi', 'teste3', 'Feminino', '1111-11-11', 'Futebol', 'Axé', 'adorável', 'agressivo', 'Fantasia', 'Ação', 'Solteiro', 'Agnóstico', 'Heterossexual', 'Brasil', NULL),
('teste4@gmail.com', '$2y$10$c.d1pUIw.KdhR/cMizlVju1AkxRlcuWc2s68.5aYXIMvKqmDrATai', 'teste4', 'Feminino', '1111-11-11', 'Futebol', 'Blues', 'afetivo', 'agressivo', 'Fantasia', 'Ação', 'Solteiro', 'Agnóstico', 'Heterossexual', 'Brasil', NULL),
('xuxa@gmail.com', '$2y$10$yze9qO0chMB4sayw3YGooe63EXkKYZfrdkwTbEVdNgN4aCxHEpt2y', 'xuxa', 'Masculino', '2006-07-21', 'Futebol', 'Pop', 'Legal', 'Chato', 'Romance', 'Romance', 'Casado', 'Ateu', 'Heterossexual', 'China', NULL),
('xuxuxu@gamil.com', '$2y$10$zNS9DHRcW/Ut14Ms6SJ09eN5KxJdOdQS6mrxVBxe3XOk168E.k6mG', 'x', 'Masculino', '1111-11-11', 'Futebol', 'Pop', 'autêntico', 'bisbilhoteiro', 'História', 'Ficção científica', 'Solteiro', 'Agnóstico', 'Homossexual', 'Argélia', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `matchsUsuario`
--
ALTER TABLE `matchsUsuario`
  ADD PRIMARY KEY (`email_usuario`,`email_match`),
  ADD KEY `email_match` (`email_match`);

--
-- Índices de tabela `mensagemDia`
--
ALTER TABLE `mensagemDia`
  ADD PRIMARY KEY (`usuario_email`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`email`);

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `matchsUsuario`
--
ALTER TABLE `matchsUsuario`
  ADD CONSTRAINT `matchsUsuario_ibfk_1` FOREIGN KEY (`email_usuario`) REFERENCES `usuario` (`email`),
  ADD CONSTRAINT `matchsUsuario_ibfk_2` FOREIGN KEY (`email_match`) REFERENCES `usuario` (`email`);

--
-- Restrições para tabelas `mensagemDia`
--
ALTER TABLE `mensagemDia`
  ADD CONSTRAINT `mensagemDia_ibfk_1` FOREIGN KEY (`usuario_email`) REFERENCES `usuario` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
