<?php

session_start();

header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "model/Usuario.php";
require_once "configs/utils.php";
require_once "configs/methods.php";

if (isMetodo("POST")) {

    //$botao= $_POST["botao"];

    // Verifica se o usuário já está logado. 
  /*   if (parametrosValidos($_SESSION,["email"])) {
        $_SESSION['erro'] = 'Você já está logado';
        header("Location: Login.php");
        exit();  
    }   */

    if (parametrosValidos($_POST, ["login"])) {
        
        if (isset($_POST["email"]) and !empty($_POST["nome"]) || isset($_POST["senha"]) and !empty($_POST["senha"]) ) {
        
            $email= $_POST["email"];
            $senha= $_POST["senha"];
            echo $email ." ". $senha;


            if (!Usuario::existeUsuarioEmail($email) ){
                //responder(400, ["status" => "Usuário não existe"]);
                $_SESSION['erro'] = 'Usuário não existe';
                header("Location: Login.php");
                exit();  
            }
            $resultado = Usuario::login($email, $senha);
            
            if (!$resultado ) {

                //responder(401, ["status" => "Usuário ou senha inválidos"]);
                // Caso usuário não exista ou a senha esteja errada
                 $_SESSION['erro'] = 'Usuário ou senha inválidos';
                header("Location: Login.php");
                exit();  

            }else{

              
                $_SESSION["email"] = $resultado;
                //responder(200, ["status" => "Seja bem-vindo!"]);
               header("Location: Index.php");
                exit();
     
            }
           
            
        }else{
            $_SESSION['erro'] = 'Preencha todos os campos';
            header("Location: Login.php");
            exit(); 
        }
        
            
    
    }if(parametrosValidos($_POST, ["cadastro"])) {
           
            $email = $_POST["email"];
            $senha = $_POST["senha"];
            $nome= $_POST["nome"];
            $genero= $_POST["genero"];
            $data_nascimento= $_POST["data_nascimento"];
            $esporte= $_POST["esporte"];
            $estilo_musical= $_POST["estilo_musical"];
            $maior_qualidade= $_POST["maior_qualidade"];
            $maior_defeito= $_POST["maior_defeito"];
            $genero_literario= $_POST["genero_literario"];
            $genero_filme= $_POST["genero_filme"];
            $status_relacionamento= $_POST["status_relacionamento"];
            $religiao= $_POST["religiao"];
            $sexualidade= $_POST["sexualidade"];
            $pais= $_POST["pais"];


            //verica a idade do usuario
            $dataAtual = new DateTime();
            $DataNascimento = new DateTime($data_nascimento);
            $intervalo_datas = $DataNascimento->diff($dataAtual);
            $idade = $intervalo_datas->y;

            //verifa se o usuario é maior/igual a 14 anos, se sim ele realiza o cadastro
            if ($idade >=14){
                if (!Usuario::existeUsuarioEmail($email)) {
                    // A função User::cadastrar já cadastra a senha criptografada no banco de dados.
                    if (Usuario::cadastrar($email, $senha, $nome, $genero, $data_nascimento, $esporte, $estilo_musical, $maior_qualidade, $maior_defeito, $genero_literario, $genero_filme, $status_relacionamento, $religiao, $sexualidade, $pais)) {
                        //$msg = ["status" => "Cadastro de usuário com sucesso!"];
                        //responder(201, $msg);
                        $_SESSION['erro'] = 'Cadastro feito com sucesso';
                        header("Location: Cadastro.php");
                        exit(); 
                    } else {
                        //$msg = ["status" => "Cadastro não pode ser realizado!"];
                        //responder(500, $msg);
                         $_SESSION['erro'] = 'Cadastro não pode ser realizado';
                        header("Location: Cadastro.php");
                        exit();  
                    }
                } else {
                    //$msg = ["status" => "Usuário já existe"];
                    //responder(400, $msg);
                     $_SESSION['erro'] = 'Usuário já existe';
                    header("Location: Cadastro.php");
                    exit();  
                }
            }else{ 
                 $_SESSION['erro'] = 'É necessário ter 14 anos ou mais para realizar o cadastro';
                header("Location: Cadastro.php");
                exit(); 
            }

        
    }if (parametrosValidos($_POST, ["editar"])) {


        $email = $_SESSION["email"];

        $genero= $_POST["genero"];
        $esporte= $_POST["esporte"];
        $estilo_musical= $_POST["estilo_musical"];
        $maior_qualidade= $_POST["maior_qualidade"];
        $maior_defeito= $_POST["maior_defeito"];
        $genero_literario= $_POST["genero_literario"];
        $genero_filme= $_POST["genero_filme"];
        $status_relacionamento= $_POST["status_relacionamento"];
        $religiao= $_POST["religiao"];
        $sexualidade= $_POST["sexualidade"];
        $pais= $_POST["pais"];

        $edicao= Usuario::editar($email,  $genero,  $esporte, $estilo_musical, $maior_qualidade, $maior_defeito, $genero_literario, $genero_filme, $status_relacionamento, $religiao, $sexualidade, $pais);
        echo  "aaa" .$edicao . " aaa";

        if ($edicao == false){
            /* $msg = ["status" => "Cadastro não pode ser realizado!"];
                    responder(500, $msg); */

                    $_SESSION['erro'] = 'Não foi possível Editar';
                    header("Location: Perfil.php");
                    exit();
        }elseif ($edicao==='sem edicao'){
            /* $msg = ["status" => "Cadastro sem nada!"];
            responder(200, $msg); */
            $_SESSION['erro'] = 'Nenhuma edição';
            header("Location: Perfil.php");
            exit();
        }else{
           /*  $msg = ["status" => "Cadastro  realizado!"];
                responder(201, $msg); */
                $_SESSION['erro'] = 'Edição realizada com sucesso';
                header("Location: Perfil.php");
                exit();
        }
        
                     
    
        

            
    }

    if (parametrosValidos($_POST, ["msgDia"])){
        $texto= $_POST["texto"];
        $email = $_SESSION["email"];

        
        if (Usuario::cadastrarMsg($email, $texto)){
           
            header("Location: Perfil.php");
            exit();
        }else{
           
            header("Location: Perfil.php");
            exit();
        }

    }
}
    

if (isMetodo("GET")) {
    //$botao= $_GET["botao"];
   // if ($botao == "logout"){
        if (parametrosValidos($_GET, ["logout"])) {
            session_destroy();
            header("Location: Login.php");
            exit();
        }
    
   // }elseif ($botao=="pesquisa"){

    if (parametrosValidos($_GET, ["pesquisa"])) {
            $listaAtributos=["genero","data_nascimento","esporte","estilo_musical", "maior_qualidade","maior_defeito","genero_literario", "genero_filme","status_relacionamento","religiao","sexualidade","pais"];
            $listaDados=[];

            
            foreach($listaAtributos as $parametroGET){
                if (isset($_GET[$parametroGET]) and !empty($_GET[$parametroGET])){
                    $listaDados[$parametroGET] = $_GET[$parametroGET];
                }
            }
           // print_r($listaDados);

            if (count($listaDados)<1){
                
                $_SESSION['erro'] = 'É necessário escolher pelo menos 5 características';
                header("Location: Pesquisa.php");
                        exit();
                    
            }else{
                    $pesquisa=Usuario::pesquisa($listaDados);
                  
                    if ($pesquisa==null){
                        $_SESSION['resultadoVazio']='Não há usuário correspondente!';
                        header("Location: Pesquisa.php");
                        exit();
                    }else{
                        
                        $_SESSION['resultado']=$pesquisa;
                        header("Location: Pesquisa.php");
                        exit();

                        
                    }  
            } 
       

          
         


    }
   
}