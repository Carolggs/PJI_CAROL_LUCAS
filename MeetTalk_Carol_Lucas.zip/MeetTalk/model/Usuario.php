<?php
require_once __DIR__ . "/../configs/BancoDados.php";

class Usuario
{

    public static function getUsuarios()
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT * FROM usuario");
            $stmt->execute();

            return $stmt->fetchAll();
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    public static function cadastrar($email, $senha, $nome, $genero, $data_nascimento, $esporte, $estilo_musical, $maior_qualidade, $maior_defeito, $genero_literario, $genero_filme, $status_relacionamento, $religiao, $sexualidade, $pais)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("INSERT INTO usuario (email, senha, nome, genero, data_nascimento, esporte, estilo_musical, maior_qualidade, maior_defeito, genero_literario, genero_filme, status_relacionamento, religiao, sexualidade, pais ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )");

            $senha = password_hash($senha, PASSWORD_BCRYPT);
            $stmt->execute([$email, $senha, $nome, $genero, $data_nascimento, $esporte, $estilo_musical, $maior_qualidade, $maior_defeito, $genero_literario, $genero_filme, $status_relacionamento, $religiao, $sexualidade, $pais]);

            if ($stmt->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function cadastrarMsg($email, $texto)
    {
       
        try {
            $conexao = Conexao::getConexao();

            $stmt= $conexao->prepare("SELECT * from mensagemDia where usuario_email=?");
            $stmt->execute([$email]);
            $res= $stmt->fetch();
           
            if ($res >0){
                $data= $res['horario'];
                $dataMsg= new DateTime($data) ;
                $dataAtual=new DateTime();
    
                $diferencaTempo = $dataAtual->diff($dataMsg);
                
                if ($diferencaTempo->days >= 1 ) {
                    $stmt2= $conexao->prepare("DELETE from mensagemDia where usuario_email=?");
                    $stmt2->execute([$email]);
                    
                    return false;
    
                   
                }else{
                    $stmt3= $conexao->prepare("UPDATE  mensagemDia SET  texto = ?, horario = NOW() WHERE usuario_email = ? ");
                    $stmt3->execute([$texto, $email]);
                    $result= $stmt3->fetchAll();
                   
                    if ($result > 0) {
                        
                        return true;
                    } else {
                      
                        return false;
                    }
    
                 
                }
            }else{
                
                $stmt4 = $conexao->prepare("INSERT INTO mensagemDia (usuario_email, texto, horario ) VALUES (?,?, NOW())");
    
                $stmt4->execute([$email, $texto]);
    
                if ($stmt4->rowCount() > 0) {
                    
                    return true;
                } else {
                    
                    return false;
                }
            }
           

           
           
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    public static function recuperaMsg($email)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT texto FROM mensagemDia WHERE usuario_email = ?");
            $stmt->execute([$email]);
            $msg=  $stmt->fetch();

            if ($msg > 0) {
               
                return $msg;
            } else {
              return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function existeUsuarioEmail($email)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT COUNT(*) FROM usuario WHERE email = ?");
            $stmt->execute([$email]);
            print_r( $stmt->execute([$email]));

            if ($stmt->fetchColumn() > 0) {
                return true;
            } else {
                echo "falso";
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function login($email, $senha)
    {
        try {
            echo "try";
            $conexao = Conexao::getConexao();
            echo "email" . $email. " ";
            echo " senha" . $senha. " ";
            $stmt = $conexao->prepare("SELECT * FROM usuario WHERE email = ? ");
            $stmt->execute([$email]);

            $resultado = $stmt->fetchAll();
            //print_r ($resultado) . "u";
        

            if (count($resultado) != 1) {
                return false;
                echo "vida";
            }

             if (password_verify($senha, $resultado[0]["senha"])) {
                echo "hei";
                return $resultado[0]["email"]; 
            } else {
                echo "oiii";
                return False;
            } 
        } catch (Exception $e) {
            echo "exception";
            echo $e->getMessage();
            exit;
        }
    }



    public static function editar($email,  $genero,  $esporte, $estilo_musical, $maior_qualidade, $maior_defeito, $genero_literario, $genero_filme, $status_relacionamento, $religiao, $sexualidade, $pais)
    {
        try {
            $conexao = Conexao::getConexao();

            $stmt= $conexao->prepare("SELECT   genero ,   esporte , estilo_musical, maior_qualidade , maior_defeito , genero_literario , genero_filme , status_relacionamento , religiao , sexualidade, pais from usuario  WHERE email = ?;");
            $stmt->execute([$email]);
            $dados = $stmt->fetch();
            print_r($dados);

            if ($dados['genero'] == $genero and $dados['esporte']==$esporte 
            and $dados['estilo_musical']== $estilo_musical and 
            $dados['maior_qualidade']==$maior_qualidade and 
            $dados['maior_defeito'] ==$maior_defeito and 
            $dados['genero_literario'] ==$genero_literario and 
            $dados['genero_filme']==$genero_filme and 
            $dados['status_relacionamento']== $status_relacionamento 
            and $dados['religiao']==$religiao and $dados['sexualidade'] ==$sexualidade
             and $dados['pais']==$pais){
               
                return 'sem edicao';
            }else{
                $stmt1 = $conexao->prepare("UPDATE usuario SET genero = ?,  esporte = ?, estilo_musical = ?, maior_qualidade = ?, maior_defeito = ?, genero_literario = ?, genero_filme = ?, status_relacionamento = ?, religiao = ?, sexualidade = ?, pais = ? WHERE email = ?;");
                $stmt1->execute([$genero, $esporte, $estilo_musical, $maior_qualidade, $maior_defeito, $genero_literario, $genero_filme, $status_relacionamento, $religiao, $sexualidade, $pais, $email]);
                $resultado = $stmt1->rowCount() ;
                if ($resultado >0) {
                    
                    return 'alterou';
                } else {
                   
                    return false;
                }
            }

        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function FotoPerfil($caminho_imagem, $email)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("UPDATE usuario SET fotoPerfil = ? WHERE email =?");
            $stmt->execute([$caminho_imagem, $email]);
            $resultado = $stmt->fetchAll();
        
            if (count($resultado) != 1) {
                return false;
            }else{
                return $resultado["fotoPerfil"];
            }

        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }



    public static function ExibirFotoPerfil($email)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT fotoPerfil  FROM usuario WHERE email = ?");
            $stmt->execute([$email]);

            $fotoPerfil = $stmt->fetch();
            if ($fotoPerfil !== false && $fotoPerfil['fotoPerfil'] !== null) {
                return $fotoPerfil["fotoPerfil"];
            } else {
                return "icon.png";
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }



    
    public static function ExibirDados($email)
    {
        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("SELECT *  FROM usuario WHERE email = ?");
            $stmt->execute([$email]);

            $dados = $stmt->fetch();
            //print_r($dados);
            if ($dados !== false && $dados!= null ) {
                return $dados;
            } 
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }

    
    public static function pesquisa($listaDados)
    {
        $select= "SELECT nome  FROM usuario WHERE ";

        $parametros="";
        foreach($listaDados as $atributo =>$valor ){
            $select .= $atributo. "=" . "'".$valor."'" ." ";
            $parametros= " $".$atributo;

            if ($atributo !== array_key_last($listaDados)) {
                $select .= " AND ";
            }
        }

        try {
            $conexao = Conexao::getConexao();
            $stmt = $conexao->prepare("$select ");
            $stmt->execute();
            $resultado = $stmt->fetchAll();
            

            if ($resultado > 0) {
               
                
                return $resultado;
            } else {
               
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }



    public static function MatchDia($email)
    {
        
        try {
            $conexao = Conexao::getConexao();

            //echo $email;

            $stmt = $conexao->prepare("SELECT email,  esporte, estilo_musical, maior_qualidade, maior_defeito, genero_literario, genero_filme, status_relacionamento, religiao, sexualidade FROM usuario WHERE email NOT IN (SELECT email_match FROM matchsUsuario WHERE email_usuario = ?)");
            $stmt->execute([$email]);
            $listaUsuarios= $stmt->fetchAll();
            //print_r($listaUsuarios);
            
            $stmt2 = $conexao->prepare("SELECT email, esporte, estilo_musical, maior_qualidade, maior_defeito, genero_literario, genero_filme, status_relacionamento, religiao, sexualidade FROM usuario where email=?");
            $stmt2->execute([$email]);
            $UsuarioSessao= $stmt2->fetch();

            $stmt3= $conexao->prepare("SELECT *  FROM  matchsUsuario WHERE email_usuario=?");
            $stmt3->execute([$email]);
            $MatchsUsuario= $stmt3->fetchAll();
            

         

            $Matchs=[];

            //ATENÇÃO A SIMILARIDADE TA CONTANDO COM O EMAIL ENTAO NUNCA VAI DAR 1;

            //similaridade de jaccard
            foreach( $listaUsuarios as $Usuario){
                $interseccao= count(array_intersect($UsuarioSessao, $Usuario));
                $uniao= count(array_merge($UsuarioSessao, $Usuario));

                $jaccard= $interseccao/$uniao;

                if ($jaccard>= 0.4 and $Usuario['email'] != $email){
                    $Usuario['jaccard'] = $jaccard;
                    array_push($Matchs, $Usuario);
                }
                
            }

            foreach ($MatchsUsuario as $indice) {
                foreach ($Matchs as $key => $ind) {
                    if ($indice['email_match'] == $ind['email']) {
                        unset($Matchs[$key]);
                    }
                }
            }

          if (!empty($Matchs or $Matchs!=null)){
                $MatchDia=$Matchs[array_rand($Matchs)];

                 //print_r($MatchDia);
                $emailMatch= $MatchDia['email'];
                //$data_atual=new DateTime();
                //echo "email ::".print_r($emailMatch);
                $stmt5= $conexao->prepare("select * from  matchsUsuario where email_usuario=? and TIMESTAMPDIFF(DAY, data_match, NOW()) < 1");
                $stmt5->execute([$email]);
                $res= $stmt5->fetch();
              
              

                if ($res == false){
                    $stmt6= $conexao->prepare("INSERT INTO matchsUsuario (email_usuario, email_match, data_match ) values(?, ?,   NOW())");
                    $stmt6->execute([$email, $emailMatch]);

                    $stmt7 = $conexao->prepare("SELECT data_match, email, nome
                    FROM matchsUsuario
                    INNER JOIN usuario ON matchsUsuario.email_match = usuario.email
                    WHERE matchsUsuario.email_usuario = ? AND TIMESTAMPDIFF(HOUR, matchsUsuario.data_match, NOW()) < 24;
                    "); 
                    $stmt7->execute([$email]);                   
                    $resultado=$stmt7->fetch();
                   
                    return $resultado; 
                }else{
                    $stmt8 = $conexao->prepare("SELECT data_match, email, nome
                    FROM matchsUsuario
                    INNER JOIN usuario ON matchsUsuario.email_match = usuario.email
                    WHERE matchsUsuario.email_usuario = ? AND TIMESTAMPDIFF(HOUR, matchsUsuario.data_match, NOW()) < 24;
                    ");                    
                    $stmt8->execute([$email]);
                    $resultado=$stmt8->fetch();

                    return $resultado;
                }
   
    
               
            }else{
               
                return false;
            }
            
           
        } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
    }


    public static function InfosMatch($email){
        try {
            $conexao = Conexao::getConexao();

            $stmt = $conexao->prepare("SELECT nome, genero, esporte, estilo_musical, maior_qualidade, maior_defeito, genero_literario, genero_filme, status_relacionamento, religiao, sexualidade FROM usuario INNER JOIN matchsUsuario ON email = email_match WHERE email_usuario = ? AND TIMESTAMPDIFF(HOUR, data_match, NOW()) < 24;");
            $stmt->execute([$email]);
            $userMatch= $stmt->fetch();
            
                return $userMatch; 
            } catch (Exception $e) {
            echo $e->getMessage();
            exit;
        }
}
}