<?php
session_start();

header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "model/Usuario.php";
require_once "configs/utils.php";
require_once "configs/methods.php";

if (isMetodo("POST")){
    $diretorio = 'uploads/';  // Diretório onde as imagens serão salvas
    $imgUploaded = $_FILES['perfilFoto']['tmp_name'];
    $tamanho= $_FILES['perfilFoto']['size'];
    $tipo = pathinfo($_FILES['perfilFoto']['name'], PATHINFO_EXTENSION);
    $uploadOk= true;


    
    if ($tamanho >1000000 ){
        $uploadOk = false;

    }
   
    if ($tipo != "png" && $tipo != "jpg") {
         $uploadOk = false;
    }

    if (!file_exists($diretorio)) {
        mkdir($diretorio, 0777, true);
    }
    
    if ($uploadOk) {
        $email = $_SESSION["email"]; 
        $nomeImagem = $email . '.' . $tipo;
 
        // Mover a imagem para o diretório de upload
        $caminho_imagem = $diretorio . $nomeImagem;
        move_uploaded_file($imgUploaded, $caminho_imagem);
     
        Usuario::FotoPerfil($caminho_imagem, $email);
    }

     
    
    
}

   

?>
