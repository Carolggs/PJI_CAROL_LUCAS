<?php
session_start();

require_once "model/Usuario.php";
require_once "configs/utils.php";
require_once "configs/methods.php";
?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">



    <title>Index</title>

</head>

<body class="bg-secondary bg-gradient bg-opacity-10 ">

    <div class="d-flex   vh-100">
        <div class=" flex ">
            <div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark vh-100 fs-5" style="width: 280px">
                <div class="profile-icon">
                    <img src="<?php echo Usuario::ExibirFotoPerfil($_SESSION["email"] )?>"
                        alt="Imagem do Banco de Dados">
                </div>
                <p class="nomeUsuario ml-4">
                    <?php 
                        $nome=Usuario::ExibirDados($_SESSION["email"]);
                        print_r($nome["nome"])
                    ?>
                </p>
                <hr class="mt-3 mb-5 ">
                <ul class="nav nav-pills flex-column mb-auto">
                    <li class="mt-3">
                        <a href="Index.php" class="nav-link active " aria-current="page">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                class="bi bi-house-fill " viewBox="0 0 16 16">
                                <path
                                    d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z" />
                                <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z" />
                            </svg>
                            Página Inicial
                        </a>
                    </li>
                    <li class="mt-5">
                        <a href="Perfil.php" class="nav-link text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                class="bi bi-person-fill" viewBox="0 0 16 16">
                                <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                            </svg>
                            Perfil
                        </a>
                    </li>
                    <li class="mt-5">
                        <a href="Conversas.html" class="nav-link text-white">
                            <strong><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                    class="bi bi-chat-fill" viewBox="0 0 16 16">
                                    <path
                                        d="M8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6-.097 1.016-.417 2.13-.771 2.966-.079.186.074.394.273.362 2.256-.37 3.597-.938 4.18-1.234A9.06 9.06 0 0 0 8 15z" />
                                </svg></strong>
                            Conversas
                        </a>
                    </li>
                    <li class="mt-5">
                        <a href="Pesquisa.php" class="nav-link text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor"
                                class="bi bi-search" viewBox="0 0 16 16">
                                <path
                                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                            Pesquisa por Usuário
                        </a>
                    </li>
                </ul>
                <hr>

                <form class="ms-4" method="GET" action="usuario.php">
                    <button class="btn btn-primary ms-5" type="submit" name="logout" value="logout">Logout</button>
                </form>
            </div>
        </div>

        

        
            


            



        <div class="p-2 flex-grow-1 mt-1 mb-5 ">
        <div class="d-flex justify-content-center mt-2 ">
        <h1 class="text-primary text-center mt-2  "><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30"
                    fill="currentColor" class="bi bi-chat-heart me-1 " viewBox="0 0 16 16">
                    <path fill-rule="evenodd"
                        d="M2.965 12.695a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6c0 3.193-3.004 6-7 6a8.06 8.06 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a10.97 10.97 0 0 0 .398-2Zm-.8 3.108.02-.004c1.83-.363 2.948-.842 3.468-1.105A9.06 9.06 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.437 10.437 0 0 1-.524 2.318l-.003.011a10.722 10.722 0 0 1-.244.637c-.079.186.074.394.273.362a21.673 21.673 0 0 0 .693-.125ZM8 5.993c1.664-1.711 5.825 1.283 0 5.132-5.825-3.85-1.664-6.843 0-5.132Z" />
                </svg>Match do Dia!</h1>

        </div>

      <?php

$match = Usuario::MatchDia($_SESSION['email']);
$dataAtual = new DateTime();


$_SESSION['matchDoDia']= $match;

if ($match == false){
    echo "<div class='d-flex justify-content-center mt-2 '>";
                    echo "<h2 class=' text-center mt-2 '>" ."Sem Match do dia!";
                    echo "<svg xmlns='http://www.w3.org/2000/svg' width='30' height='30' fill='currentColor' class='bi bi-heartbreak-fill ms-1' viewBox='0 0 16 16'>";
                   echo "<path d='M8.931.586 7 3l1.5 4-2 3L8 15C22.534 5.396 13.757-2.21 8.931.586ZM7.358.77 5.5 3 7 7l-1.5 3 1.815 4.537C-6.533 4.96 2.685-2.467 7.358.77Z'/>";
                    echo "</svg>";
                    echo "</h2>";
                 
                    echo "</div>";
}




if(isset($_SESSION['matchDoDia']) ){
    if ($match!=null){
        if (!empty($match)) {
  

   
            if ($match != false){
                $dataMatch = $match['data_match'];
                $datinha= new DateTime($dataMatch);
                $diferencaTempo = $dataAtual->diff($datinha);
            
                if ($diferencaTempo->days >= 1 or $dataAtual >= $datinha) {
                
                    $match = Usuario::MatchDia($_SESSION['email']);
                    $_SESSION['matchDoDia']= $match;
                } else{
                    $_SESSION['matchDoDia']= $match;
                }
    
           
                $user= Usuario::infosMatch($_SESSION['email']); 

               
                $nome= $user["nome"];

                //echo " odio vc ".print_r($_SESSION['recusar']);
                
    
                if (isset($_SESSION['matchDoDia'])){

                    
                   
                    echo "<div class='d-flex justify-content-center mt-3 ' name='match' id='match'>";
                        echo "<div class='card shadow' style='width: 500px'>";
    
                            echo "<div class='card-body'>";
                                echo"<h5 class='card-title'> $nome </h5>";
                                echo "<p class='card-text'></p>";
    
    
                                echo "<div class='d-flex  mb-3'>";
                                echo "<div class='me-auto p-2 '>";
                                    //echo "<form class='ms-2' method='GET' action='usuario.php'>";
                                        echo"<a href='Conversas.html'><button class='btn btn-primary' type='submit' name='conversarMatch'
                                        value='conversarMatch'>" .'Conversar'."</button> </a>";
      
                                    //echo" </form>";
                                echo" </div>";
                            
                            /* echo "<div class='p-2'>"; // O alg do botao estava dando problema
                                echo "<div class='me-auto p-2 '>";
                                
                                echo "<button class='btn btn-primary' id='recusar' type='submit' name='recusar'>" .'Recusar'. "</button>";
                                
                                echo" </div>";
    
    
                            echo" </div>"; */
    
                        echo" </div>";
    
                    echo" </div>"; 
                }else{
                    echo "lula";
                    echo "<div class='d-flex justify-content-center mt-2 '>";
                    echo "<h2 class=' text-center mt-2 '>" ."Sem Match do dia!";
                    echo "<svg xmlns='http://www.w3.org/2000/svg' width='30' height='30' fill='currentColor' class='bi bi-heartbreak-fill' viewBox='0 0 16 16'>";
                   echo "<path d='M8.931.586 7 3l1.5 4-2 3L8 15C22.534 5.396 13.757-2.21 8.931.586ZM7.358.77 5.5 3 7 7l-1.5 3 1.815 4.537C-6.533 4.96 2.685-2.467 7.358.77Z'/>";
                    echo "</svg>";
                    echo "</h2>";
                 
                    echo "</div>";
                }
        
            
            }else{
               
                echo "<div class='d-flex justify-content-center mt-2 '>";
                    echo "<h2 class=' text-center mt-2 '>" ."Sem Match do dia!";
                    echo "<svg xmlns='http://www.w3.org/2000/svg' width='30' height='30' fill='currentColor' class='bi bi-heartbreak-fill' viewBox='0 0 16 16'>";
                   echo "<path d='M8.931.586 7 3l1.5 4-2 3L8 15C22.534 5.396 13.757-2.21 8.931.586ZM7.358.77 5.5 3 7 7l-1.5 3 1.815 4.537C-6.533 4.96 2.685-2.467 7.358.77Z'/>";
                    echo "</svg>";
                    echo "</h2>";
                 
                    echo "</div>";
                
            }
        }
    }

}else{
   
    echo "<div class='d-flex justify-content-center mt-2 '>";
    echo "<h2 class=' text-center mt-2 '>" ."Sem Match do dia!";
    echo "<svg xmlns='http://www.w3.org/2000/svg' width='30' height='30' fill='currentColor' class='bi bi-heartbreak-fill' viewBox='0 0 16 16'>";
   echo "<path d='M8.931.586 7 3l1.5 4-2 3L8 15C22.534 5.396 13.757-2.21 8.931.586ZM7.358.77 5.5 3 7 7l-1.5 3 1.815 4.537C-6.533 4.96 2.685-2.467 7.358.77Z'/>";
    echo "</svg>";
    echo "</h2>";
 
    echo "</div>";
}


  ?>
            </div>
        </div>


    </div>


</body>

</html>