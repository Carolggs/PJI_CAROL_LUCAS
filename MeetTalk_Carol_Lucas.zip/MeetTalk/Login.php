<?php
session_start();

// Verificar se a variável de sessão 'usuario' está vazia
 if (!empty($_SESSION['email'])) {
    session_destroy();
    
}  

?>


<!DOCTYPE html>
<html lang="pt">


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Login</title>
</head>

<body class="bg-secondary bg-gradient bg-opacity-10 vh-100 overflow-hidden ">


    <h1 class="content text-primary  text-center mt-5 pt-5 mb-5" style="font-size: 60px; "><svg
            xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-chat-heart "
            viewBox="0 0 16 16">
            <path fill-rule="evenodd"
                d="M2.965 12.695a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6c0 3.193-3.004 6-7 6a8.06 8.06 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a10.97 10.97 0 0 0 .398-2Zm-.8 3.108.02-.004c1.83-.363 2.948-.842 3.468-1.105A9.06 9.06 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.437 10.437 0 0 1-.524 2.318l-.003.011a10.722 10.722 0 0 1-.244.637c-.079.186.074.394.273.362a21.673 21.673 0 0 0 .693-.125ZM8 5.993c1.664-1.711 5.825 1.283 0 5.132-5.825-3.85-1.664-6.843 0-5.132Z" />
        </svg>MeetTalk</h1>


    <div class="d-flex justify-content-center mt-1  ">
        <form class=" shadow  mb-2 bg-white border  border-2 rounded-3 mt-2" style="width: 400px; height: 350px;"
            method="POST" action="usuario.php">
            <div class="ms-4 me-4 ">
                <strong>
                    <p class="mt-3 fs-4 text-center">Faça seu Login</p>
                </strong>


                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">E-mail </label>
                    <input class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" type="email"
                        name="email" placeholder="E-mail" required>
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input class="form-control" id="exampleInputPassword1" type="password" name="senha"
                        placeholder="Senha" required>
                </div>

                <button type="submit" name="login" value="login" class="btn btn-primary">Entrar</button>

                <?php
          

          if (isset($_SESSION['erro'])) {
            echo '<p style="color: red;">' . $_SESSION['erro'] . '</p> ';
            unset($_SESSION['erro']); // Limpa a mensagem de erro para não exibi-la novamente após o refresh da página
          }
      ?>

                <p class="mt-1">Não tem uma Conta? <strong><a href="Cadastro.php" style="text-decoration: none">
                            Cadastre-se </a></strong></p>
            </div>
        </form>




    </div>
</body>

</html>